package edu.baylor.ecs.si;

public class AnyHolder<AnyBike> {
    private AnyBike bike;

    public AnyHolder(AnyBike bike) {
        this.bike = bike;
    }
}
