package edu.baylor.cs.junit.hooks;

import org.junit.jupiter.api.Test;

public class HelperCalledBySuiteTests {
	@Test
	void test() {
	}
}
